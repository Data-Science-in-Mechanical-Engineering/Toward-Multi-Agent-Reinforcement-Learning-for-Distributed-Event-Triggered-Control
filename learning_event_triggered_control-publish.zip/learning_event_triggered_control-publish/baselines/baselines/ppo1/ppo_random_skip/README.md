The files in here represent a modification to the original ppo1 implementation from baselines.
